package cadastroDeClienteBancoDeDados;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ClienteDAO {
	
	public void inserir(Cliente cliente) {
		String sql = "INSERT INTO clientes (nome, email) VALUES (?, ?)";
		try (Connection conn = Conexao.getConnection();
			PreparedStatement stmt = conn.prepareStatement(sql)) {
			
			stmt.setString(1, cliente.getNome());
			stmt.setString(2, cliente.getEmail());
			stmt.executeUpdate();
			
			System.out.println("Cliente inserido com sucesso!");
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public List<Cliente> listarCliente() {	
		List<Cliente> list = new ArrayList<>();
		String sql = "SELECT * FROM clientes";
		
		try (Connection conn = Conexao.getConnection();
			PreparedStatement stmt = conn.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery()) {
			
			while (rs.next()) {
				Cliente cliente = new Cliente();
				cliente.setId(rs.getInt("id"));
				cliente.setNome(rs.getString("nome"));
				cliente.setEmail(rs.getString("email"));
				list.add(cliente);	
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	
	public void atualizar(Cliente cliente) {
		String sql = "UPDATE clientes SET nome=?, email=? WHERE id=?";
		try (Connection conn = Conexao.getConnection();
			PreparedStatement stmt = conn.prepareStatement(sql)) {
			
			stmt.setString(1, cliente.getNome());
			stmt.setString(2, cliente.getEmail());
			stmt.setInt(3, cliente.getId());
			stmt.executeUpdate();
			
			System.out.println("Cliente atualizado com sucesso!");
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void	deletar(int id) {
		String sql = "DELETE FROM clientes WHERE id=?";
		try (Connection conn = Conexao.getConnection();
			PreparedStatement stmt = conn.prepareStatement(sql)) {
			
			stmt.setInt(1, id);
			stmt.executeUpdate();
			
			System.out.println("Cliente removido com sucesso!");
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
