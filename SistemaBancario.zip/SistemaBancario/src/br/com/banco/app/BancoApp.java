package br.com.banco.app;

import br.com.banco.model.Conta;
import br.com.banco.model.Tributavel;
import br.com.banco.contas.ContaCorrente;
import br.com.banco.contas.ContaPoupanca;

public class BancoApp {
    public static void main(String[] args) {
        Conta[] contas = new Conta[2];
        contas[0] = new ContaCorrente(1, "João", 1000.0);
        contas[1] = new ContaPoupanca(2, "Maria", 1200.0);

        contas[0].sacar(50);
        contas[1].depositar(0); // mantem o saldo

        for (Conta conta : contas) {
            System.out.println("\n" + conta.getClass().getSimpleName() + " - " + conta.getTitular());
            conta.exibirSaldo();

            if (conta instanceof Tributavel tributavel) {
                System.out.printf("Tributo: R$ %.2f%n", tributavel.calcularTributo());
            }
        }
    }
}
